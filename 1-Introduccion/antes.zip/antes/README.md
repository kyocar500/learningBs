# Bootstrap 4 Start Template
Kick Start your Bootstrap 4 Project with this lightweight template, it only loads the require bootstrap files plus a stylesheet and a javascript file for your custom code.

## Instructions

- Download this project
- Decompress
- Change directory name
- Build Something great

